package sesion02_mul_a;

public class Cartesiana {
	private float x;
	private float y;
	public Cartesiana (float x, float y){
	this.x=x;
	this.y=y;
	}

	public Cartesiana(){

	}
	public Cartesiana cartesiana_polar(float radio, float angulo){
	float x= radio * (float)Math.cos(angulo);
	float y=radio * (float)Math.sin(angulo);
	System.out.println("Resutado("+x+")("+y+")");
	return new Cartesiana(x,y);
	}


	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}
	
}
