package sesion02_mul_a;

public class Polar {
private float radio;
private float angulo;


public Polar(float radio, float angulo) {
	super();
	this.radio = radio;
	this.angulo = angulo;
}
public Polar polar_cartesiano(float x, float y) {
	float radio=(float) Math.sqrt(Math.pow(x, 2)+(Math.pow(y, 2)));
	float angulo=(float) Math.atan(x/y);
	System.out.println("Radio: "+radio+"�. Angulo: "+angulo+"�");
	return new Polar(radio,angulo);
	
}
public float getAngulo() {
	return angulo;
}

public void setAngulo(float angulo) {
	this.angulo = angulo;
}

public float getRadio() {
	return radio;
}

public void setRadio(float radio) {
	this.radio = radio;
}

}
