package sesion02_mul_a;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		Scanner capt = new Scanner(System.in);
		System.out.print("Ingresar tipo de cambio de coordenada:\n"
				+ "1) Polar a Cartesiana.\n2) Cartesiana a polar. ");
		int res= capt.nextInt();
		if (res==1) {
			System.out.print("Ingresar Radio:  ");float radio= capt.nextFloat();
			System.out.print("Ingresar Angulo:  ");float angulo= capt.nextFloat();
			Cartesiana a= new Cartesiana(radio,angulo);
			a.cartesiana_polar(radio, angulo);
		}else if(res==2) {
			System.out.print("Ingresar X:  ");float x= capt.nextFloat();
			System.out.print("Ingresar Y:  ");float y= capt.nextFloat();
			Polar a= new Polar(x,y);
			a.polar_cartesiano(x, y);
		}
		
	}

}
